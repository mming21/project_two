package project.two.shadow;

public interface NaverService {
	String test(String file);	
}

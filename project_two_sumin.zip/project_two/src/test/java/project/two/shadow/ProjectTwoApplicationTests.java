package project.two.shadow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}

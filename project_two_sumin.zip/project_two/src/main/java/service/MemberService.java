package service;

public interface MemberService {
	//기능 필수
	public void register();
	public void login();

}
